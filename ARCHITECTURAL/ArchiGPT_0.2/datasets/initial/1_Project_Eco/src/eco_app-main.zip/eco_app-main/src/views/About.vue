<template>
  <div class="about mt-5">
    Progetto universitario per il monitoring di agenti inquinanti nei comuni italiani,<br> con supporto di segnalazioni da parte dei cittadini ed interfaccia grafica web.
  </div>
</template>

<script>


export default {
  name: "About",

  computed : {

  },
  
  beforeCreate(){
  
  },

  methods : {
  }
}
</script>